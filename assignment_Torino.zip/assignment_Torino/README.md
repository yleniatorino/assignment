# Assignment

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 14.2.6.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The application will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory.

## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via a platform of your choice. To use this command, you need to first add a package that implements end-to-end testing capabilities.

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI Overview and Command Reference](https://angular.io/cli) page.



Ho sfruttato le informazioni sopra riportate per rispondere ai primi punti richiesti nell'assignment, in riferimento alla run e built.
Il progetto consiste in un'applicazione single page che mostra di default le gif in tendenza; se invece viene inserita una chiave nella barra di ricerca, vengono caricate le gif con quel parametro. Infine, cliccando su una gif viene aperta una finestra popup che mostra la gif con informazioni ulteriori. 

Ho creato un componente per ogni funzionalità, ovvero un per la toolbar, uno per la searchbar, uno che mostra tutte le gif e, per ultimo, il popup con le informazioni relative. Per organizzare la parte di scripting ho creato un service che gestisce la chiamata http e fa i controlli sui dati in input, per poi venire "iniettato" nel file gifs.components.ts. Inoltre, ho usato gli observable per ottenere l'oggetto contenente le gif, il BehaviorSubject per inserire nel sito con le gif selezionate, e le Pipes per standardizzare le date. 

Per creare questo progetto mi sono appoggiata ad Angular Materials: l'ho scelta per avere a disposizione un vasto numero di elementi standardizzati già ottimizzati. Stavo cercando di implementare l'infinite scroll ma credo che mi dedicherò prima alla parte di sviluppo backend/db così da avere un quadro più completo del funzionamento di Angular.
