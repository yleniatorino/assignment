import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { BehaviorSubject } from 'rxjs';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root'
})

export class DataService {
  trending = 'https://api.giphy.com/v1/gifs/trending?api_key='+ environment.giphyApiKey +'&limit=100'
  control = new BehaviorSubject<any>([])
  cont: any

  constructor(private http: HttpClient, private datePipe: DatePipe) { }

  trendingGifs(){
    //gestione che gestisce la chiamata http di default
    this.http.get(this.trending).subscribe((response: any) =>{
      response.data = this.cleanData(response.data)
      this.control.next(response.data)
    })
    return this.control
  }

  searchGif(chiave: string){
    //funzione che gestisce la chiamata http per la search
    let search = 'https://api.giphy.com/v1/gifs/search?q='+ chiave +'&api_key=' + environment.giphyApiKey + '&limit=50'
    this.http.get(search).subscribe((response: any) =>{
      response.data = this.cleanData(response.data)
      this.control.next(response.data)
    })
    return this.control
  }

  getGifs(){
    //funzione di controllo per l'observable
    return this.control.asObservable()
  }

  cleanData(valore: any){
    valore.forEach((val: any) =>{
      //viene generato un array, prendo il primo elemento splitted, ovvero il titolo
      val.title = val.title.split(' GIF', 1)[0]
      val.import_datetime = this.datePipe.transform(val.import_datetime, 'dd/MM/yyyy')

      //controlli
      if (val.username == ""){
        val.username = "Sconosciuto"
      }
      if (!val.user || val.user.description == ""){
        val.user = {}
        val.user.description = "Nessuna descrizione"
      }
      if (!val.trending_datetime || val.trending_datetime == "0000-00-00 00:00:00"){
        val.trending_datetime = Date.now()
      }
      val.trending_datetime = this.datePipe.transform(val.trending_datetime, 'dd/MM/yyyy')
    })
    return valore
  }
}
