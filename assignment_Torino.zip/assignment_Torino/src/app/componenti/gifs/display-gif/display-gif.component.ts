import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-display-gif',
  templateUrl: './display-gif.component.html',
  styleUrls: ['./display-gif.component.css']
})
export class DisplayGifComponent implements OnInit {
  @Input() data: any
  @Output() closePopup = new EventEmitter<boolean>()

  constructor() { }

  ngOnInit(): void {
  }
  closeP(){
    this.closePopup.emit(false)
  }
}
