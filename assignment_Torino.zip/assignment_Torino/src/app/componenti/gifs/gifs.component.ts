import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-gifs',
  templateUrl: './gifs.component.html',
  styleUrls: ['./gifs.component.css']
})
export class GifsComponent implements OnInit, OnDestroy {
  gifs: any = []
  sub!: Subscription;
  valori: any = []
  clicked = false
  dGif: any = []


  constructor(private dataService: DataService) { }

  ngOnInit(): void {
    //nel momento in cui viene inizializzata la pagina, vengono caricate le gif
    this.valori = this.dataService.trendingGifs().subscribe((response: any) => {
      this.valori = response
    })
    this.sub = this.dataService.getGifs().subscribe((response: any) => {
      this.gifs = response
    })
  }

  ngOnDestroy(): void {
    //si effettua la disiscrizione dall'observable
    this.sub.unsubscribe()
  }

  onClick(element: any){
    //mostra il componente che ospita il popup con la descrizione della gif
    this.dGif = element
    this.clicked = true
  }

  receivePopup(){
    //elimina il componente dalla pagina
    this.clicked = false
  }
}
